package com.example.orderapp.attività;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.orderapp.R;

public class nuovoordine extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuovoordine);

        Button backButton = findViewById(R.id.backbutton);
        Button pastaMeno = findViewById(R.id.pastaMeno);
        Button pastaPiu = findViewById(R.id.pastaPiu);
        Button risoMeno = findViewById(R.id.risoMeno);
        Button risoPiu = findViewById(R.id.risoPiu);
        Button carneMeno = findViewById(R.id.carneMeno);
        Button carnePiu = findViewById(R.id.carnePiu);
        Button pesceMeno = findViewById(R.id.pesceMeno);
        Button pescePiu = findViewById(R.id.pescePiu);
        Button patatineMeno = findViewById(R.id.patatineMeno);
        Button patatinePiu = findViewById(R.id.patatinePiu);
        Button insalataMeno = findViewById(R.id.insalataMeno);
        Button insalataPiu = findViewById(R.id.insalataPiu);
        Button acquaMeno = findViewById(R.id.acquaMeno);
        Button acquaPiu = findViewById(R.id.acquaPiu);
        Button vinoMeno = findViewById(R.id.vinoMeno);
        Button vinoPiu = findViewById(R.id.vinoPiu);
        TextView numPasta = findViewById(R.id.numPasta);
        TextView numRiso = findViewById(R.id.numRiso);
        TextView numCarne = findViewById(R.id.numCarne);
        TextView numPesce = findViewById(R.id.numPesce);
        TextView numPatatine = findViewById(R.id.numPatatine);
        TextView numInsalata = findViewById(R.id.numInsalata);
        TextView numAcqua = findViewById(R.id.numAcqua);
        TextView numVino = findViewById(R.id.numVino);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        pastaMeno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementa(numPasta);
            }
        });
        pastaPiu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementa(numPasta);
            }
        });
        risoMeno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementa(numRiso);
            }
        });
        risoPiu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementa(numRiso);
            }
        });
        carneMeno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementa(numCarne);
            }
        });
        carnePiu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementa(numCarne);
            }
        });
        pesceMeno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementa(numPesce);
            }
        });
        pescePiu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementa(numPesce);
            }
        });
        patatineMeno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementa(numPatatine);
            }
        });
        patatinePiu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementa(numPatatine);
            }
        });
        insalataMeno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementa(numInsalata);
            }
        });
        insalataPiu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementa(numInsalata);
            }
        });
        acquaMeno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementa(numAcqua);
            }
        });
        acquaPiu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementa(numAcqua);
            }
        });
        vinoMeno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementa(numVino);
            }
        });
        vinoPiu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementa(numVino);
            }
        });
    }

    public void incrementa(TextView v){
        String currentValue = v.getText().toString();
        int value = Integer.parseInt(currentValue);
        value++;
        v.setText(String.valueOf(value));
    }

    public void decrementa(TextView v){
        String currentValue = v.getText().toString();
        int value = Integer.parseInt(currentValue);
        value--;
        v.setText(String.valueOf(value));
    }
}
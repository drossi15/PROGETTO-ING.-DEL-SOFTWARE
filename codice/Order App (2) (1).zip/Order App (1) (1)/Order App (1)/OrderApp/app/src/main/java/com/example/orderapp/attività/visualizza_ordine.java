package com.example.orderapp.attività;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextPaint;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.orderapp.R;
import com.example.orderapp.database.*;

public class visualizza_ordine extends AppCompatActivity {
    private ConnectionHelper db= new ConnectionHelper();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizza_ordine);
        TextView conferma=findViewById(R.id.textOrdine);
        Button cercaOrdine =  findViewById(R.id.buttonCercaOrdine);
        EditText numOrdine = findViewById(R.id.ricercaOrdine);
        //ScrollView elencoOrdine = findViewById(R.id.elencoOrdini);
        if(db.connectionDB()==1){
            conferma.setText("success");
        }
        else conferma.setText("fail");





        cercaOrdine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //db.visualizza_ordini();
                //ricercaDatabase(numOrdine);

            }
        });

    }



    private void ricercaDatabase(EditText num){      // prende in input il numero d'ordine inserito
        //FUNZIONE DI RICERCA DELL'ORDINE SPECIFICO E LO MOSTRA NELLA SCROLLVIEW
    }
}
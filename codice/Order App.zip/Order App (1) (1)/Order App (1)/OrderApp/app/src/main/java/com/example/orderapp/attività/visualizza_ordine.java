package com.example.orderapp.attività;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextPaint;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.orderapp.R;
import com.example.orderapp.database.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class visualizza_ordine extends AppCompatActivity {
    public ConnectionHelper db= new ConnectionHelper();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizza_ordine);
        Connection con;
        TextView text=findViewById(R.id.textOrdine);
        Button cercaOrdine =  findViewById(R.id.buttonCercaOrdine);
        EditText numOrdine = findViewById(R.id.ricercaOrdine);
        //ScrollView elencoOrdine = findViewById(R.id.elencoOrdini);
        con=db.connectionDB();





        cercaOrdine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (con != null) {
                    try {
                        Statement statement = con.createStatement();
                        ResultSet resultSet = statement.executeQuery("Select * from TEST_TABLE;");
                        while (resultSet.next()) {
                            text.setText(resultSet.getString(1));
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }

                } else {
                     text.setText("Conncection is null");

                }

            }
        });

    }



    private void ricercaDatabase(EditText num){      // prende in input il numero d'ordine inserito
        //FUNZIONE DI RICERCA DELL'ORDINE SPECIFICO E LO MOSTRA NELLA SCROLLVIEW
    }
}
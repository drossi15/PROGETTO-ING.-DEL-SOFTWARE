package com.example.orderapp.attività;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.orderapp.R;
import com.example.orderapp.database.DatabaseHelper;

public  class nuovaprenotazione_activity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nuova_prenotazione);


        Button buttonAggiungi=findViewById(R.id.buttonAggiungi);
        EditText orario,nome,cellulare,tavolo ;
        orario=findViewById(R.id.editTextTextPersonName);
        nome=findViewById(R.id.editTextTextPersonName2);
        cellulare=findViewById(R.id.editTextTextPersonName3);
        tavolo=findViewById(R.id.editTextNumber);

        buttonAggiungi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DatabaseHelper mydb=new DatabaseHelper(nuovaprenotazione_activity.this);

                mydb.aggiungiPrenotazione(orario.getText().toString().trim(),
                        nome.getText().toString().trim(),
                        cellulare.getText().toString().trim(),
                        Integer.parseInt(tavolo.getText().toString().trim()));


            }
        });

    }


}
package com.example.orderapp.database;
import android.os.StrictMode;
import android.util.Log;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ConnectionHelper {
    Connection con;
    String uname,pass,ip,port,database;

    public Connection connectionclass()
    {
        ip="192.168.178.82";
        database="DB orderapp";
        uname="diego";
        pass="password";
        port="1433";
        StrictMode.ThreadPolicy policy= new StrictMode.ThreadPolicy.Builder().permitAll().build();
        Connection connection= null;
        String ConnectionURL= null;

        try
        {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
         ConnectionURL= "jdbc:jtds:sqlserver://"+ ip + ":"+ port+";"+ "databasename="+ database+";user="+uname+";password="+pass+";";
        connection= DriverManager.getConnection(ConnectionURL);
        }
        catch (Exception ex){
            Log.e("Error", ex.getMessage());
        }
        return connection;
    }

    public void insertPrenotazione(String orario,String nome,String cellulare,String tavolo){
        Connection connection=connectionclass();
        try
        {
            if(connection!=null){
                String sqlinsert="Insert into PRENOTAZIONE values (orario,nome,cellulare,tavolo)";
                Statement st= connection.createStatement();
                ResultSet rs= st.executeQuery(sqlinsert);
            }
        }
        catch(Exception exception){
            Log.e("Error",exception.getMessage());
        }
    }
}

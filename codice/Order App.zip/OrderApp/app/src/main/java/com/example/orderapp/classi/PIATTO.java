package com.example.orderapp.classi;






public class PIATTO {

    private String nome;
    private float prezzo;
    private int id;


    private String allergeni;

    public String getNome() {
        return this.nome;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public int getId() {
        return id;
    }

    public String getAllergeni() {
        return this.allergeni;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setAllergeni(String allergeni) {
        this.allergeni= allergeni;
    }


    public void MostraDati() {

    }

}
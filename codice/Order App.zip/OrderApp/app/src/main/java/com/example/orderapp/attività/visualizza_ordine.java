package com.example.orderapp.attività;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextPaint;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.orderapp.R;

public class visualizza_ordine extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizza_ordine);

        Button cercaOrdine =  findViewById(R.id.buttonCercaOrdine);
        EditText numOrdine = findViewById(R.id.ricercaOrdine);
        ScrollView elencoOrdine = findViewById(R.id.elencoOrdini);

        cercaOrdine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ricercaDatabase(numOrdine);
            }
        });
    }



    private void ricercaDatabase(EditText num){      // prende in input il numero d'ordine inserito
        //FUNZIONE DI RICERCA DELL'ORDINE SPECIFICO E LO MOSTRA NELLA SCROLLVIEW
    }
}
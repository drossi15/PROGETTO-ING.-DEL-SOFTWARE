package com.example.orderapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonCameriere=findViewById(R.id.buttonCameriere);
        Button buttonCuoco=findViewById(R.id.buttonCuoco);


        buttonCameriere.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
            setContentView(R.layout.cameriere);


            }
        });
        buttonCuoco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setContentView(R.layout.cuoco);
            }
        });
    }
}
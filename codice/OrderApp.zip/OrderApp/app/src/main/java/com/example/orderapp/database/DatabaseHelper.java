package com.example.orderapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    private Context context;
    private static final String DATABASE_NAME="orderapp.db";

    private static final String TABLE_NAME1="PRENOTAZIONE";
    private static final String TABLE_NAME2="TAVOLO";
    private static final String TABLE_NAME3="ORDINE";
    private static final String TABLE_NAME4="PIATT0";
    private static final String TABLE_NAME5="CONTIENE";

    private static final String ID_PRENOTAZIONE="ID_PRENOTAZIONE";
    private static final String ORARIO="ORARIO";
    private static final String NOME_PRENOTAZIONE="NOME_PRENOTAZIONE";
    private static final String CELLULARE="CELLULARE";
    private static final String STATO_PRENOTAZIONE="STATO_PRENOTAIZONE";
    private static final String ID_TAVOLO="ID_TAVOLO";

    private static final String STATO_TAVOLO="STATO_TAVOLO";


    private static final String ID_ORDINE="ID_ORDINE";
    private static final String PREZZO_ORDINE="PREZZO_ORIDNE";
    private static final String STATO_ORDINE="STATO_ORDINE";

    private static final String ID_PIATTO="ID_PIATTO";
    private static final String NOME_PIATTO="NOME_PIATTO";
    private static final String PREZZO_PIATTO="PREZZO_PIATTO";


       public DatabaseHelper(@Nullable Context context) {
           super(context, DATABASE_NAME,null,1);
           this.context=context;
    }





    @Override
    public void onCreate(SQLiteDatabase db) {

        String query1= "CREATE TABLE "+ TABLE_NAME1 +
                " (" + ID_PRENOTAZIONE + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ORARIO +"TEXT, " +
                NOME_PRENOTAZIONE +"TEXT, " +
                CELLULARE + "TEXT, "+
                STATO_PRENOTAZIONE + "TEXT, " +
                ID_TAVOLO +"INTEGER);";

        String query2= "CREATE TABLE "+ TABLE_NAME2 +
                " (" + ID_TAVOLO + " INTEGER PRIMARY KEY , " +
                STATO_TAVOLO +"TEXT); ";


        String query3= "CREATE TABLE "+ TABLE_NAME3 +
                " (" + ID_ORDINE + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                PREZZO_ORDINE+"FLOAT, "+
                STATO_ORDINE +"TEXT, "+
                ID_TAVOLO +"INTEGER); ";

        String query4= "CREATE TABLE "+ TABLE_NAME4 +
                " (" + ID_PIATTO + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NOME_PIATTO + "TEXT, "+
                PREZZO_PIATTO +"TEXT); ";

        String query5= "CREATE TABLE "+ TABLE_NAME5 +
                " (" + ID_PIATTO + " INTEGER, " +
                ID_ORDINE +"INTEGER); ";

        db.execSQL(query1);

        db.execSQL(query2);
       db.execSQL(query3);
       db.execSQL(query4);
       db.execSQL(query5);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
      db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME1);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME2);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME3);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME4);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME5);
      onCreate(db);
    }

     public void aggiungiPrenotazione(String orario,String nome,String cellulare,int tavolo){
        SQLiteDatabase db=this.getWritableDatabase();
         ContentValues cv= new ContentValues();

         cv.put(ORARIO, orario);
         cv.put(NOME_PRENOTAZIONE,nome);
         cv.put(CELLULARE,cellulare);
         cv.put(ID_TAVOLO,tavolo);

         long result=db.insert(TABLE_NAME1, null,cv);
         if(result==-1) Toast.makeText(context, "Failed",Toast.LENGTH_SHORT).show();
         else Toast.makeText(context, "Added Successfully",Toast.LENGTH_SHORT).show();
     }
}

package com.example.orderapp.attività;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;

import com.example.orderapp.R;

public class visualizza_prenotazione extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizza_prenotazione);

        Button cercaPrenotazioni = findViewById(R.id.buttonCercaPrenotazioni);
        ScrollView elencoPrenotazioni = findViewById(R.id.elencoPrenotazioni);

        cercaPrenotazioni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ricercaDatabase();
            }
        });
    }

    private void ricercaDatabase(){
               //FUNZIONE DI RICERCA DI TUTTE LE PRENOTAZIONI E LE MOSTRA NELLA SCROLLVIEW
    }
}
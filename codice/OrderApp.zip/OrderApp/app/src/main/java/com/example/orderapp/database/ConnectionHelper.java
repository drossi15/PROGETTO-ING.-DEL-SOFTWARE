package com.example.orderapp.database;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.orderapp.R;
import com.example.orderapp.attività.visualizza_ordine;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionHelper extends AppCompatActivity {

    private static String ip = "192.168.178.82";
    private static String port = "1433";
    private static String Classes = "net.sourceforge.jtds.jdbc.Driver";
    private static String database = "testDatabase";
    private static String username = "test";
    private static String password = "test";
    private static String url = "jdbc:jtds:sqlserver://" + ip + ":" + port + "/" + database;
    private Connection connection = null;


    public Connection connectionDB() {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try {

            Class.forName(Classes);
            connection = DriverManager.getConnection(url, username, password);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return connection;
    }

    public void Insert_prenotazione(String orario,String nome,String cellulare, int tavolo,Connection cn){
        if (cn != null) {
            try {
                Statement statement = cn.createStatement();
                ResultSet resultSet = statement.executeQuery("Insert into PRENOTAZIONE (ORARIO,NOME,CELLULARE,NUMERO_TAVOLO)" +
                        "VALUES ('"+orario+"','"+nome+"','"+cellulare+"','"+tavolo+"')");

            } catch (SQLException e) {
                e.printStackTrace();

            }

        } else

        {


        }
    }

}



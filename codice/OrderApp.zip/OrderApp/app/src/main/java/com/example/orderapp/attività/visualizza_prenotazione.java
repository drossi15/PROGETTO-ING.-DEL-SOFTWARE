package com.example.orderapp.attività;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.orderapp.R;
import com.example.orderapp.database.ConnectionHelper;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class visualizza_prenotazione extends AppCompatActivity {
    public ConnectionHelper db1= new ConnectionHelper();
     Connection con1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizza_prenotazione);
        ScrollView elencoPrenotazioni = findViewById(R.id.elencoPrenotazioni);
        TextView textPre=findViewById(R.id.textPrenotazione3);
        TextView textPre2=findViewById(R.id.textPrenotazione4);
        con1=db1.connectionDB();
        if (con1 != null) {
            try {
                Statement statement = con1.createStatement();
                ResultSet resultSet = statement.executeQuery("Select * from PRENOTAZIONE;");
                while (resultSet.next()) {
                    String s=new String();
                    String y= new String();
                    for(int i=1;i<=6;i++){
                        y=resultSet.getString(i);
                        s=s+","+y;
                    }
                    textPre.setText(s);

                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

        } else {
            textPre.setText("Conncection is null");

        }


    }


}
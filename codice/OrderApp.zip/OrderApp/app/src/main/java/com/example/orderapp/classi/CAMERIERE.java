
package com.example.orderapp.classi;


public class CAMERIERE extends UTENTE {


    public void NuovoOrdine() {

    }

    public void CancellaOrdine() {

    }

    public void NuovaPrenotazione(String orario,String nome, String cellulare,int tavolo ) {

    }

    public void CancellaPrenotazione() {

    }

    public void CheckPrenotazione() {

    }

    public void ModificaOrdine() {

    }

    public void ModificaPrenotazione() {

    }

    public void VisualizzaPrenotazione() {

    }

}
package com.example.orderapp.classi;





// ----------- << imports@AAAAAAGFpbSJJq/fXTw= >>
// ----------- >>

// ----------- << class.annotations@AAAAAAGFpbSJJq/fXTw= >>
// ----------- >>
public class PIATTO {
    // ----------- << attribute.annotations@AAAAAAGFpbd2yrQdEG0= >>
    // ----------- >>
    private String nome;

    // ----------- << attribute.annotations@AAAAAAGFpbeGtLRmWtk= >>
    // ----------- >>
    private float prezzo;

    // ----------- << attribute.annotations@AAAAAAGFpbeaIbTxs9s= >>
    // ----------- >>
    private int id;

    // ----------- << attribute.annotations@AAAAAAGFr6jusZbDqPk= >>
    // ----------- >>
    private String allergeni;

    public String getNome() {
        return this.nome;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public int getId() {
        return id;
    }

    public String getAllergeni() {
        return this.allergeni;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setAllergeni(String allergeni) {
        this.allergeni= allergeni;
    }

    // ----------- << method.annotations@AAAAAAGFr6i3dZVy+us= >>
    // ----------- >>
    public void MostraDati() {
    // ----------- << method.body@AAAAAAGFr6i3dZVy+us= >>
    // ----------- >>
    }
// ----------- << class.extras@AAAAAAGFpbSJJq/fXTw= >>
// ----------- >>
}
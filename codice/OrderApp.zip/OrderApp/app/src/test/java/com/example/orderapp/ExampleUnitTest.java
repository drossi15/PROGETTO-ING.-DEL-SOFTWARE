package com.example.orderapp;

import org.junit.Test;

import static org.junit.Assert.*;

import android.os.StrictMode;

import com.example.orderapp.database.ConnectionHelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */

public class ExampleUnitTest {

    @Test



    public void Connection_not_null() {

    }




    public void Inserimento() throws SQLException {

    }



}
